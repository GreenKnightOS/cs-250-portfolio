import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;

public class SlideShow extends JFrame {
	private static final long serialVersionUID = 1L;

	// Declare variables used to build the slideshow interface.
	private JPanel slidePane;
	private JPanel textPane;
	private JPanel buttonPane;
	private CardLayout card;
	private CardLayout cardText;
	private JButton btnPrev;
	private JButton btnNext;
	private JLabel lblSlide;
	private JLabel lblTextArea;

	/**
	 * Create the application.
	 */
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initComponent() {
		// Initialize layout managers and panels used for the image slides and text slides.
		card = new CardLayout();
		cardText = new CardLayout();
		slidePane = new JPanel();

		textPane = new JPanel();
		textPane.setBackground(new Color(34, 80, 70));
		textPane.setBounds(5, 470, 790, 50);
		textPane.setVisible(true);

		buttonPane = new JPanel();
		buttonPane.setBackground(new Color(220, 235, 230));

		btnPrev = new JButton();
		btnNext = new JButton();
		lblSlide = new JLabel();
		lblTextArea = new JLabel();

		// Set up the frame attributes for the wellness travel slideshow.
		setSize(800, 600);
		setLocationRelativeTo(null);
		setTitle("Top 5 Detox and Wellness Destinations");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Set the layouts for the panels.
		slidePane.setLayout(card);
		textPane.setLayout(cardText);

		// Add each wellness destination slide and matching text description.
		// These updates reflect the Product Owner's new requirement to focus
		// the booking tool on detox and wellness travel.
		for (int i = 1; i <= 5; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();
			lblSlide.setText(getResizeIcon(i));
			lblTextArea.setText(getTextDescription(i));
			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}

		getContentPane().add(slidePane, BorderLayout.CENTER);
		getContentPane().add(textPane, BorderLayout.SOUTH);

		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

		btnPrev.setText("Previous");
		btnPrev.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();
			}
		});
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		buttonPane.add(btnNext);

		getContentPane().add(buttonPane, BorderLayout.NORTH);
	}

	/**
	 * Previous Button Functionality
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}

	/**
	 * Next Button Functionality
	 */
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}

	/**
	 * Method to get the images.
	 * Loads the updated detox and wellness travel images from the resources folder.
	 */
	private String getResizeIcon(int i) {
		String image = "";

		if (i == 1) {
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/TestImage1.jpg") + "'></body></html>";
		} else if (i == 2) {
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/TestImage2.jpg") + "'></body></html>";
		} else if (i == 3) {
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/TestImage3.jpg") + "'></body></html>";
		} else if (i == 4) {
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/TestImage4.jpg") + "'></body></html>";
		} else if (i == 5) {
			image = "<html><body><img width='800' height='500' src='" + getClass().getResource("/resources/TestImage5.jpg") + "'></body></html>";
		}

		return image;
	}

	/**
	 * Method to get the text values.
	 * Returns the updated wellness destination descriptions based on the
	 * Product Owner's new detox/wellness travel requirement.
	 */
	private String getTextDescription(int i) {
		String text = "";

		if (i == 1) {
			text = "<html><body><font color='white' size='5'>#1 Blue Lagoon, Iceland</font><br><font color='white'>Relax in world-famous geothermal waters and enjoy a peaceful wellness retreat.</font></body></html>";
		} else if (i == 2) {
			text = "<html><body><font color='white' size='5'>#2 Costa Rica Wellness Resort</font><br><font color='white'>Reconnect with nature through spa treatments, rainforest views, and healthy living.</font></body></html>";
		} else if (i == 3) {
			text = "<html><body><font color='white' size='5'>#3 Tulum, Mexico</font><br><font color='white'>Enjoy beachfront wellness experiences, yoga retreats, and crystal-clear waters.</font></body></html>";
		} else if (i == 4) {
			text = "<html><body><font color='white' size='5'>#4 Bali, Indonesia</font><br><font color='white'>Practice yoga and meditation while surrounded by tropical landscapes.</font></body></html>";
		} else if (i == 5) {
			text = "<html><body><font color='white' size='5'>#5 Sedona, Arizona</font><br><font color='white'>Experience mindfulness, wellness activities, and stunning red rock scenery.</font></body></html>";
		}

		return text;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}